function setup() {
  createCanvas(400, 400);
}

function draw() {
  createCanvas(400, 400);
}

function draw() {
  if (mouseIsPressed) {
    fill(100);
  } else {
    fill(200);
  }
  ellipse(mouseX, mouseY, 80, 80);
}